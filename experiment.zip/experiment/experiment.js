//---------------------content(help and info)-----------------------------

var helpContent;
var infoContent;

function Help(){

    helpContent="";
    helpContent = helpContent + "<h2>Simple attraction and repulsion between magnets help</h2>";
    helpContent = helpContent + "<h3>About the experiment</h3>";
    helpContent = helpContent + "<p>The experiment shows forces between two magnets constrained by left, right of table.</p>";
    helpContent = helpContent + "<h3>Exeriment is conducted in three steps:</h3>";

    helpContent = helpContent + "<ul>";
    helpContent = helpContent + "<li>Step 1&nbsp;&nbsp;:Click on one of the buttons (Repulsion or Attraction).</li>";
    helpContent = helpContent + "<li>Step 2&nbsp;:&nbsp;Start the Experiment by clicking on Start button.</li>";
    helpContent = helpContent + "<li>Step 3&nbsp;:&nbsp;Drag one of the magnet two see the effect.</li>";
    helpContent = helpContent + "</ul>";
    

    helpContent = helpContent + "<h3>Other controls</h3>";
    helpContent = helpContent + "<ul>";
    helpContent = helpContent + "<h4><li>Start Button&nbsp;&nbsp;:&nbsp;Starts the experiment.</li></h4>";
    helpContent = helpContent + "<h4><li>Reset Button&nbsp;&nbsp;:&nbsp;resets or reloads the Experiment.</li></h4>";
    helpContent = helpContent + "<h4><li>Animation control&nbsp;&nbsp;:&nbsp;It has two panels  .</li></h4>";
    helpContent = helpContent + "<h5>magnet1X:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li>Controls the X position of the magnet1.</li>";
    helpContent = helpContent + "<h5>magnet2X:&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;&nbsp;<li>Controls the X position of the magnet2.</li>";
    helpContent = helpContent + "</ul>";

    helpContent = helpContent + "<h3>The drag and drop</h3>";
    helpContent = helpContent + "<p>position of magnet is changed by dragging it ( y axis is made constant for ease of experiment).</p>";
    helpContent = helpContent + "<h2>End of the Experiment</h2>";

    PIEupdateHelp(helpContent);
}


function Info(){
 infoContent =  "";
    infoContent = infoContent + "<h2>Simple attraction and repulsion between magnets info</h2>";
    infoContent = infoContent + "<h3>About the experiment</h3>";
    infoContent = infoContent + "<p>The experiment shows forces between two magnets constrained by left, right of table.</p>";
    infoContent = infoContent + "<p>when two magnet brought closer to each other two forces act depending on the orientataion <br>of both magnets(north and south pole) .</p>";
    infoContent = infoContent + "<h4>The two forces are :</h4>";
    infoContent = infoContent + "<h4>Attraction<br>Repulsion</h4>";
    infoContent = infoContent + "<h3>Repulsion</h3>";
    infoContent = infoContent + "<p>When two magnets with opposit orientataion (N===S  S===N) are brought closer two each other, both magnet repel each other.</p>";
    infoContent = infoContent + "<p>Since the force of friction is relatively less than force of repulsion between two magnets, the other magnets starts to move in same direction as does the 1st magnet.</p>";
    infoContent = infoContent + "<p>As soon as 2nd magnet collides with the left side of the table ,the end of table stops it from moving it further.</p>";
    infoContent = infoContent + "<h3>Attraction</h3>";
    infoContent = infoContent + "<p>When two magnets with same orientataion (N===S  N===S) are brought closer two each other, both magnets attact each other.</p>";
    infoContent = infoContent + "<p>Since the force of friction is relatively less than force of attraction between two magnets, the other magnets starts to move in opposit direction.</p>";
    infoContent = infoContent + "<p>Once two manget get attracted to each other , the 2nd manget follows the same movement as does the 1st magnet.</p>";
    infoContent = infoContent + "<p>Again the movement of both magnets is resticted by end of  the table.</p>";
    infoContent = infoContent + "<h2>End of the Experiment</h2>";
    PIEupdateInfo(infoContent);
}

// =---------------------------end of content------------------------------------

 
//-------------------------------global variables--------------------------------------
    
    var mySceneTLX  =  -8.0;
    var mySceneTLY  =  4.0;
    var mySceneBRX  =  8.0;
    var mySceneBRY  =  -4.0;
    var mySceneW    =  (mySceneBRX - mySceneTLX);
    var mySceneH    =  (mySceneTLY - mySceneBRY);
    var myCenterX   =  (mySceneTLX + mySceneBRX) / 2.0;
    var myCenterY   =  (mySceneTLY + mySceneBRY) / 2.0;
    var tableH      =  .8;
    var tableL      =  mySceneW;
    var tableW      =  mySceneH;

    var myCubeZ     =  -20;
    var magnetZ     =  -20;
    var magnetL     =  2.6;
    var magnetH     =  .8;
    var magnetW     =  .8;
    var magnet1X    ;
    var magnet1Y    ;
    var magnet2X    ;
    var magnet2Y    ;
    var magnet1Xupdate ;
    var magnet2Xupdate ;
    var magnet2;
    var magnet1;
    var i ;


function assignValue(){
    magnet1X    =  magnetL;
    magnet1Y    =  myCenterY + tableH/2 + magnetH/2;
    magnet2X    =  -magnetL;
    magnet2Y    =  myCenterY + tableH/2 + magnetH/2;

    }


//----------------------------------end of variable------------------------------




//  ---------------------drag control of objects-----------------------------


   function magnet1drag(element, newpos){

    magnet1X = newpos.x;
    magnet1Xupdate = newpos.x;
    var magnet1Xupdate = newpos.x;
   
    if(newpos.x > mySceneBRX - (magnetL/2) ){
        magnet1X = mySceneBRX - (magnetL/2);

    }

    if (i == 0) {

        if (newpos.x <= (mySceneTLX + (magnetL + magnetL))) {
           magnet1X = mySceneTLX + (magnetL + magnetL);
        } 
    }


    else if(i == 1) {

        if (newpos.x <= (mySceneTLX + (magnetL + magnetL/2))) {
           magnet1X = mySceneTLX + (magnetL + magnetL/2);
        }
    }

    
    magnet1Y = newpos.y;
    
    if (newpos.y > myCenterY || newpos.y < myCenterY) {

        magnet1Y = myCenterY + tableH/2 + magnetH/2;;
    }
    
    magnetZ = newpos.z;
    magnet1.position.set(magnet1X,magnet1Y,magnetZ);


}
  

// =-----------------------------------end of drag control--------------------------------------


   // --------------------------------------control------------------




var magnetXmin       =  mySceneTLX+(magnetL/2+magnetL/4);
var magnetXmax       =  mySceneBRX - (magnetL/2+magnetL/4);
var Xincreament      =  0.2;
var magnet1Xdefault  =  magnetL;
var magnet2Xdefault  =  -magnetL;


   function updatemagnet1X(newValue)
{
    magnet1X = newValue;
    magnet1.position.set(magnet1X,magnet1Y,magnetZ);
    PIErender();
}

  function updatemagnet2X(newValue)
{
    magnet2X = newValue;
    magnet2.position.set(magnet2X,magnet2Y,magnetZ);
    PIErender();
}


   function Controls()
{
    
assignValue();


 //------------------------input panel------------------------------

  PIEaddInputSlider("magnet1X", magnet1Xdefault, updatemagnet1X, magnetXmin, magnetXmax, Xincreament);
  PIEaddInputSlider("magnet2X", magnet2Xdefault, updatemagnet2X, magnetXmin, magnetXmax, Xincreament);

  PIEaddDisplayText("magnet1X:", magnet1X);
  PIEaddDisplayText("magnet2X:", magnet2X);

  PIErender();

//-------------------------end of input panel-----------------------------

  
  }


//  ------------------end of control-----------------


//------------------------ loading experiment elements -------------------

function loadExperimentElements()
{


    PIEsetExperimentTitle("Simple attraction and repulsion between magnets");
    PIEsetDeveloperName("Ravi Shankar Chauhan");
    PIEhideControlElement();
    Help();
    Info();
    Controls();
    assignValue();
     
    var edgeL = new THREE.Mesh(new THREE.BoxGeometry(.8,tableH+1,tableW,28,30),
                new THREE.MeshBasicMaterial(
                       {
                            color:0x00ff00,
                            wireframe:true
                        }
                )
            );

    edgeL.position.set(mySceneTLX-.5,myCenterY+(tableH+1)/4,myCubeZ-.3);


    PIEaddElement(edgeL);



    var edgeR = new THREE.Mesh(new THREE.BoxGeometry(.8,tableH+1,tableW,28,30),
                new THREE.MeshBasicMaterial(
                    {
                        color:0x00ff00,
                        wireframe:true
                    }
                )
            );
        

    edgeR.position.set(mySceneBRX+.5,myCenterY+(tableH+1)/4,myCubeZ-.3);


    PIEaddElement(edgeR);


var geometry = new THREE.BoxGeometry(tableL, tableH, tableW);
        var material = new THREE.MeshBasicMaterial({color: 0xaaaaaa,wireframe:false});
        var table = new THREE.Mesh(geometry, material);
        table.position.set(myCenterX,myCenterY, myCubeZ);

        PIEaddElement(table);
       


//-------------------------------magnet 1--------------------------------

 magnet1 = new THREE.Mesh(new THREE.BoxGeometry(magnetL,magnetH,magnetW),
    new THREE.MeshLambertMaterial({
        color:0xFF1493
    }));
        magnet1.position.set(magnet1X,magnet1Y,magnetZ);
        magnet1.receiveShadow= true;
        magnet1.castShadow = true;
        var amblight = new THREE.AmbientLight(0xF3FFE2,0.5);
        PIEaddElement(amblight);

        var poinlight = new THREE.PointLight(0xF3FFE2,1);
        PIEaddElement(poinlight);


    PIEaddElement(magnet1);
    PIEdragElement(magnet1);        
    PIEsetDrag(magnet1, magnet1drag);


//-------------------------------end of magnet 1--------------------------------               



//-------------------------------magnet 2--------------------------------

 magnet2 = new THREE.Mesh(new THREE.BoxGeometry(magnetL,magnetH,magnetW),new THREE.MeshLambertMaterial({color:0x1E90FF}));
        magnet2.position.set(magnet2X,magnet2Y,magnetZ);
        magnet2.receiveShadow= true;
        magnet2.castShadow = true;

        PIEaddElement(magnet2);
     //   PIEdragElement(magnet2);
   // PIEsetDrag(magnet2, magnet2drag);


//-------------------------------end magnet 2--------------------------------

        
//light
var light = new THREE.AmbientLight(0xffffff, 0.5);
        PIEaddElement(light);
        
        var light1 = new THREE.PointLight(0xffffff, 0.5);
        PIEaddElement(light1);

  
        PIEsetAreaOfInterest(mySceneTLX, mySceneTLY, mySceneBRX, mySceneBRY);
        PIEcamera.position.set(0,2,0);

  }



function resetExperiment()
{

     var magnet1X    =  magnetL;
     var magnet2X    =  -magnetL;
     
     magnet1.position.set(magnet1X,magnet1Y,magnetZ);
     magnet2.position.set(magnet2X,magnet2Y,magnetZ);
     i = 5;
    
     location.reload();

   }

   

   function repulsion(){
    i = 0;

   }
function attraction(){
    i = 1;
  
}

var news = magnet1X;
function updateExperimentElements(t, dt)


{


    if (i == 0) {




        if (magnet1X > mySceneTLX + (2*magnetL)){

            if ((magnet1X - magnet2X) <= (magnetL+magnetL/2)) {

            magnet2X = magnet1X- (magnetL+magnetL/2);
            magnet2.position.set(magnet2X,magnet2Y,magnetZ);


          }
    }
 }



    if (i == 1) {

        if ((magnet1X - magnet2X) <= (magnetL+magnetL/2)) {

            magnet2X = magnet1X - (magnetL);
            magnet2.position.set(magnet2X,magnet2Y,magnetZ);


        }
     }   
    
    
}

